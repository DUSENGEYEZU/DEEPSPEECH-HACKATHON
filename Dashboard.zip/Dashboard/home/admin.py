from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(comanyContact)
#admin.site.register(Iteractivegrath)
#admin.site.register(prediction)
