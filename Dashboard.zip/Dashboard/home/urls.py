from django.urls import path
from . import views



urlpatterns = [

path("", views.home, name='home'),
#path("search/", views.SearchResultsList.as_view(), name="search_results"),
path("search/", views.get_queryset, name='search_results'),
path("record/", views.recoding, name='recoding'),
path('search/<id>', views.details, name='details'),
]
