#from mmap import MADV_AUTOSYNC
from django.db import models

# Create your models here.
from django.db import models
from django.core.validators import FileExtensionValidator
from django.utils import timezone
from django.contrib.postgres.indexes import GinIndex  # new
from django.contrib.postgres.search import SearchVectorField
from django.db import models


""" class grath(models.Model):
    id = models.AutoField(primary_key=True)
    grath_title = models.CharField(max_length=100)
    description = models.TextField()
    thumbnail = models.FileField( upload_to='images/', validators=[FileExtensionValidator(allowed_extensions=['png', 'jpg', 'jpeg','html'])])
    created_date = models.DateTimeField(default=timezone.now)
   
class prediction(models.Model):
    id = models.AutoField(primary_key=True)
    date = models.DateTimeField()
    user_name = models.CharField(max_length=100)
    user_location = models.CharField(max_length=100)
    text = models.TextField()
    label = models.CharField(unique=False,null=True ,max_length=100)

class Iteractivegrath(models.Model):
    id = models.AutoField(primary_key=True)
    grath_title = models.CharField(max_length=100)
    description = models.TextField()
    thumbnail = models.FileField( upload_to='images/', validators=[FileExtensionValidator(allowed_extensions=['html'])])
    created_date = models.DateTimeField(default=timezone.now)
    """
class comanyContact(models.Model):
    name=models.CharField(max_length=500)
    weblink=models.CharField(max_length=500)
    contact=models.CharField(max_length=500)
    details=models.TextField(max_length=10000)
    """ search_vector = SearchVectorField(null=True)
    # new
    class Meta:
        indexes = [
            GinIndex(fields=["search_vector"]),
        ] """
    def __str__(self):
        return f"{self.details} rero wa ba hamagara kuri {self.contact} na web site yabo ni {self.weblink}"

   