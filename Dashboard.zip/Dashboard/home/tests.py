import requests

jwt_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxNiwiZXhwIjoxNjQ4NDU3OTI1LjkyNzl9.TVXIkpCl0lcj4M6kE8f1qTTXPuWx8ij_HCDVkT13CWg"
headers = {'Authorization': 'Bearer ' + jwt_token}
url = 'https://mbaza.dev.cndp.org.rw/deepspeech/api/api/v1/stt/http'
hot_words = {'paris': -1000, 'power': 1000, 'parents': -1000}
audio_filename = 'recorded.wav'
audio = [('audio', open(audio_filename, 'rb'))]

response = requests.post(url, data=hot_words, files=audio, headers=headers)
messageob=response.json()
massage=messageob['message']
print(massage)  