#from _typeshed import Self
import requests
import os
from django.db.models import Q
from django.contrib.postgres.search import SearchVector, SearchQuery, SearchRank, SearchHeadline
from django.db.models import Q
from django.utils.decorators import method_decorator
from django.views.generic import ListView
from django.views.decorators.cache import cache_page
import speech_recognition as sr
#import SpeechRecognition as sr


from django.shortcuts import render
#import numpy as np
#import matplotlib.pyplot as plt
#import scipy.stats as stats


import json
#import  pandas as pd
#import cufflinks as cf
from.models import *
""" 
def home(request):
   
  charts=grath.objects.order_by('-created_date')[:5]
  chartIters=Iteractivegrath.objects.order_by('created_date')[:5]
   
  context = {
    'charts': charts,
    'chartIters': chartIters,
    }
    
  return render(request, 'home/welcome.html',context)
 """


def home(request):
   charcomanies=comanyContact.objects.order_by('name')[:5]
 
   
   context = {
    'charcomanies': charcomanies,
    
    }
    
   return render(request, 'home/welcome.html',context)



""" class SearchResultsList(ListView):
    model = comanyContact
    context_object_name = "companiesReturns"
    template_name = "home/welcome.html"

    def get_queryset(self):
        query = self.request.GET.get("q")
        #query='query'
        resultlist=[]
        listosearch=["RIB","police"," amategeko"]
        for i in listosearch:
        #print(f" ibi nibyo wasabye {query}")
            result=comanyContact.objects.annotate(search=SearchVector("details", "name")).filter(search=i)
            listosearch.append(result)
        return listosearch """

def get_queryset(request):
        query = request.GET.get("q")
        #print(query)
        #splitlist=query.split()
        #print(splitlist)
        #query='query'
        resultlist=[]
        #listosearch=["RIB","police"," amategeko"]
        listosearch=query.split()
        print(listosearch)
        for i in listosearch:
        #print(f" ibi nibyo wasabye {querSy}")
            result=comanyContact.objects.annotate(search=SearchVector("details", "name")).filter(search=i)
            resultlist.append(result)
   
   
        context = {
             'companiesReturns': resultlist,
             }
    
        return render(request, 'home/welcome.html',context)

def recoding(request):
    r = sr.Recognizer()

    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source)

        print("Please say something")

        audio = r.listen(source)

        print("Recognizing Now .... ")


        # recognize speech using google

        try:
            print("You have said \n" + r.recognize_google(audio))
            print("Audio Recorded Successfully \n ")


        except Exception as e:
            print("Error :  " + str(e))
        
        # write audio
        with open("recorded.wav", "wb") as f:
            f.write(audio.get_wav_data())

    # commverting recorded oudio to 
    jwt_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxNiwiZXhwIjoxNjQ4NDU3OTI1LjkyNzl9.TVXIkpCl0lcj4M6kE8f1qTTXPuWx8ij_HCDVkT13CWg"
    headers = {'Authorization': 'Bearer ' + jwt_token}
    url = 'https://mbaza.dev.cndp.org.rw/deepspeech/api/api/v1/stt/http'
    hot_words = {'paris': -1000, 'power': 1000, 'parents': -1000}
    audio_filename = 'recorded.wav'
    audio = [('audio', open(audio_filename, 'rb'))]

    response = requests.post(url, data=hot_words, files=audio, headers=headers)
    messageob=response.json()
    message=messageob['message']
    context = {
             'message': message,
             }
      
       
    return render(request, 'home/welcome.html',context)

def details(request,id):
   charcoman=comanyContact.objects.get(id =id)
 
   print(charcoman)
   context = {
    'charcoman': charcoman,
    
    }
    
   return render(request, 'home/moredetail.html',context)



        